# 기존 일반 펌웨어에서 Command 홀드 동작만 추가

이 묶음은 Studio 전환용이 아닙니다. 기존 일반 펌웨어의 커스텀 키맵에 Command 홀드 동작을 추가한 Actions #34입니다.

- 소스: https://github.com/cherrytomato1/modu-c-zmk-config/tree/655179f832267e335b49efa65c1d96191a65b31a
- 빌드: https://github.com/cherrytomato1/modu-c-zmk-config/actions/runs/35213624641
- 기존 동시 입력 콤보 유지. 오른쪽 엄지 Backspace 단독은 Backspace, 왼쪽 Command를 먼저 누르고 누르면 Command+Space. 기본 Mac/Windows 레이어에 적용.

기존 일반 펌웨어를 사용하는 경우 이번 키맵 변경은 새 modu_left.uf2를 왼쪽 기기에 설치하면 적용됩니다. 오른쪽에 이미 맞는 일반 펌웨어가 설치돼 있어야 합니다. 오른쪽도 설치할 때는 오른쪽을 별도로 USB 연결하고 modu_right.uf2만 복사합니다. 두 파일을 같은 기기에 넣지 마십시오.

1. Windows에서 ZIP을 모두 압축 풉니다.
2. 왼쪽 기기를 데이터 USB로 연결합니다.
3. 엄지 Fn → 왼쪽 Ctrl을 누른 채 숫자5를 한 번 누른 뒤 모두 뗍니다.
4. MODU_BOOT 드라이브에 firmware/modu_left.uf2 하나를 복사하고 자동 재부팅을 기다립니다.
5. Mac/Windows 기본 레이어에서 Backspace 단독, Command를 1초 이상 먼저 누른 뒤 Backspace, 기존 동시 입력 콤보를 확인합니다.

단축키가 안 되면 해당 기기의 물리 RESET을 빠르게 두 번 누릅니다. 위치/사진: https://erkeys.com/user-guide/reset-firmware/
드라이브 포맷이나 초기화를 요구하면 취소합니다.

Studio로 전환할 예정이면 이 묶음 대신 다음 안내서의 Studio ZIP으로 양쪽을 설치하십시오:
https://github.com/cherrytomato1/modu-c-zmk-config/tree/main/windows-studio-guide

빌드/파일 검증과 별개로 실제 기기 동작은 아직 시험 전입니다.
