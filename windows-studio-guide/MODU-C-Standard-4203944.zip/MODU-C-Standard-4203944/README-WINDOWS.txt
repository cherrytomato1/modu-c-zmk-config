# 기존 일반 펌웨어에서 새 방향키·기호열·Command 홀드 동작 적용

이 묶음은 Studio 전환용이 아닙니다. 기존 일반 펌웨어의 커스텀 키맵에 Command 홀드 동작과 새 Fn 배열을 포함한 Actions #40입니다.

- 소스: https://github.com/cherrytomato1/modu-c-zmk-config/tree/420394469f12cd572c2cabc5b9834bc5054315b3
- 빌드: https://github.com/cherrytomato1/modu-c-zmk-config/actions/runs/35221173023
- 기존 동시 입력 콤보 유지. 오른쪽 엄지 Backspace 단독은 Backspace, 왼쪽 Command를 먼저 누르고 누르면 Command+Space. 기본 Mac/Windows 레이어에 적용.

기존 일반 펌웨어를 사용하는 경우 이번 키맵 변경은 새 modu_left.uf2를 왼쪽 기기에 설치하면 적용됩니다. 오른쪽에 이미 맞는 일반 펌웨어가 설치돼 있어야 합니다. 오른쪽도 설치할 때는 오른쪽을 별도로 USB 연결하고 modu_right.uf2만 복사합니다. 두 파일을 같은 기기에 넣지 마십시오.

1. Windows에서 ZIP을 모두 압축 풉니다.
2. 왼쪽 기기를 데이터 USB로 연결합니다.
3. 엄지 Fn → 왼쪽 Ctrl을 누른 채 숫자5를 한 번 누른 뒤 모두 뗍니다.
4. MODU_BOOT 드라이브에 firmware/modu_left.uf2 하나를 복사하고 자동 재부팅을 기다립니다.
5. Mac/Windows 기본 레이어에서 Backspace 단독, Command를 1초 이상 먼저 누른 뒤 Backspace, 기존 동시 입력 콤보를 확인합니다.

단축키가 안 되면 해당 기기의 물리 RESET을 빠르게 두 번 누릅니다. 위치/사진: https://erkeys.com/user-guide/reset-firmware/
드라이브 포맷이나 초기화를 요구하면 취소합니다.

Studio로 전환할 예정이면 이 묶음 대신 다음 안내서의 Studio ZIP으로 양쪽을 설치하십시오:
https://github.com/cherrytomato1/modu-c-zmk-config/tree/main/windows-studio-guide

빌드/파일 검증과 별개로 실제 기기 동작은 아직 시험 전입니다.

## 레이어 2: 오른손 방향키와 왼손 기호

아래 표의 문자는 **기본 레이어의 물리 키 위치**입니다. 엄지 Fn을 누르고 해당 키를 누릅니다.

| 키 위치 | J | K | L | ; |
| --- | --- | --- | --- | --- |
| Fn을 누른 동안 | ← | ↓ | ↑ | → |

| 키 위치 | Q | W | E | R | T |
| --- | --- | --- | --- | --- | --- |
| Fn을 누른 동안 | - | = | [ | ] | 작은따옴표(') |

- **Mac 기본 전환: Fn+F**, **Windows 기본 전환: Fn+G**. 예전 Fn+T는 이제 작은따옴표입니다.
- Home은 **Fn+S**입니다.
- 원래 H/J/K/L의 마우스 버튼은 **U/I/O/P**로 같은 순서(오른쪽/왼쪽/가운데/오른쪽 클릭)로 이동했습니다. Fn+Y 가운데 클릭, Fn+N 왼쪽 클릭도 유지됩니다.
- Fn+H와 Fn+D는 아래 기본 레이어의 키를 사용합니다. F12, 숫자패드 기능, 관리 레이어 및 기존 Command+Space 동작은 유지됩니다.


## 레이어 2: 맨 윗줄 전체 F1~F12

엄지 Fn을 누르면 맨 윗줄12개가 왼쪽 끝부터 F1~F12로 동작합니다.

| 절반 | 맨 왼쪽부터 순서대로 |
| --- | --- |
| 왼쪽 윗줄 | F1 · F2 · F3 · F4 · F5 · F6 |
| 오른쪽 윗줄 | F7 · F8 · F9 · F10 · F11 · F12 |

물리 Esc 위치는 **Fn을 누른 동안 F1**, Fn을 떼면 원래 Esc입니다. 레이어2 윗줄의 기존 물결표 자리는 F1로 대체됐습니다. 아래쪽 키와 관리 레이어의 부트로더 단축키는 유지됩니다.

