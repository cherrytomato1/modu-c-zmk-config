# MODU-C: Windows에서 Studio 설치하고 키 바꾸기

**아래 ZIP 하나를 내려받으면 됩니다.** 새 좌우 펌웨어, 이전 버전 복구 파일, 소스, 안내서가 모두 들어 있습니다.

➡️ **[설치 파일 전체 다운로드 — MODU-C-Studio-8175d9d.zip](https://github.com/cherrytomato1/modu-c-zmk-config/raw/refs/heads/main/windows-studio-guide/MODU-C-Studio-8175d9d.zip)**

기존 Mac/Windows/Fn/관리 4개 레이어, Caps 탭·홀드, Command+Space 콤보를 보존한 개인용 Studio 펌웨어입니다. **왼쪽 Command를 먼저 누르고 있다가 오른쪽 엄지 Backspace를 눌러도 Command+Space**가 되도록 추가했습니다. 기준은 기존 Actions #32이며, Studio 버전은 **#35 / 8175d9d**입니다. 빌드와 파일 검증은 끝났고 **실제 기기 설치·Studio 연결은 아직 시험 전**입니다.

## 전체 순서

**Windows 켜기 → ZIP 다운로드·압축 풀기 → 왼쪽 설치 → 오른쪽 설치 → 왼쪽 USB 연결 → Studio 잠금 해제 → 키 변경·저장**

| 단계 | USB를 연결할 기기 | 사용할 파일 또는 동작 |
| --- | --- | --- |
| 왼쪽 설치 | **왼쪽** | `install-studio/modu_left.uf2` |
| 오른쪽 설치 | **오른쪽** | `install-studio/modu_right.uf2` |
| Studio 사용 | **왼쪽** | [zmk.studio](https://zmk.studio/) 접속 |

**한쪽 드라이브에 두 파일을 모두 넣으면 안 됩니다.** 오른쪽 키의 매핑도 왼쪽이 관리하지만, 오른쪽 펌웨어 파일 자체는 오른쪽 기기에 설치합니다. 이번 첫 전환에서는 양쪽을 각각 업데이트합니다.

## 1. Windows를 켜고 파일 준비

1. Windows에 로그인하고 인터넷에 연결합니다.
2. **Microsoft Edge**를 엽니다. Chrome을 이미 쓰고 있다면 Chrome도 됩니다. Git, Python, VS Code 등 개발 도구는 필요 없습니다.
3. 위 **설치 파일 전체 다운로드** 링크를 누릅니다. 파일 페이지가 열리면 **Download raw file** 다운로드 아이콘을 누릅니다.
4. 파일 탐색기에서 **다운로드** 폴더를 엽니다.
5. `MODU-C-Studio-8175d9d.zip`을 오른쪽 클릭 → **모두 압축 풀기** → **압축 풀기**를 누릅니다.
6. 압축을 푼 안쪽의 `MODU-C-Studio-8175d9d` 폴더를 엽니다. 아래 두 파일이 보이면 준비 완료입니다.

```text
MODU-C-Studio-8175d9d/
├─ README-WINDOWS.txt           이 안내서의 오프라인 사본
├─ install-studio/
│  ├─ modu_left.uf2             왼쪽에 설치할 새 파일
│  └─ modu_right.uf2            오른쪽에 설치할 새 파일
├─ backup-7677fa5/
│  ├─ firmware/                문제가 생기면 돌아갈 기존 좌우 파일
│  └─ source-7677fa5.zip        기존 소스 보관용
├─ source-studio-8175d9d.zip     새 소스 보관용
├─ BUILD.txt                   빌드 출처
├─ VALIDATION.md               검증 결과
└─ SHA256SUMS.txt               파일 무결성 확인용
```

소스 ZIP은 보관용입니다. **키보드에 복사하는 것은 UF2 파일 하나뿐**입니다. 라이선스와 출처 파일도 묶음에 포함돼 있습니다.

데이터 전송이 되는 USB 케이블과 양쪽 키보드를 준비합니다. 작업 중 MODU-C가 잠시 입력을 못 하므로 노트북 내장 키보드나 예비 키보드를 사용할 수 있으면 편합니다.

## 2. 왼쪽에 새 펌웨어 설치

1. MODU-C 양쪽 전원을 켜고, **왼쪽 기기의 USB 포트**를 Windows에 연결합니다.
2. **엄지 Fn을 누른 상태에서 왼쪽 Ctrl도 누르고, 숫자 5만 한 번 누른 뒤 모두 뗍니다.**
3. 파일 탐색기의 **내 PC**에 새로 나타난 `MODU_BOOT` 드라이브를 엽니다.
4. 압축 푼 `install-studio` 폴더에서 **`modu_left.uf2` 하나만** 그 드라이브 안으로 복사합니다.
5. 복사가 끝나고 기기가 자동 재부팅할 때까지 케이블을 그대로 둡니다. 부트로더 드라이브가 사라지는 것은 정상적인 재부팅 과정입니다.

**완료 표시:** 복사가 끝났고 부트로더 드라이브가 사라졌습니다. 실제 입력과 좌우 연결은 양쪽 설치 후 확인합니다.

드라이브가 안 나타나면 아래 **“키 조합으로 부트로더에 못 들어갈 때”**를 따라갑니다. 숫자 5와 6을 동시에 누르지 않습니다.

## 3. 오른쪽에 새 펌웨어 설치

1. 이제 USB 케이블을 **오른쪽 기기의 USB 포트**로 옮깁니다.
2. 양쪽 전원과 좌우 연결을 유지하고 **엄지 Fn → 왼쪽 Ctrl을 계속 누른 채 숫자 6만 한 번 누른 뒤 모두 뗍니다.**
3. 파일 탐색기에서 새로 나타난 `MODU_BOOT` 드라이브를 엽니다.
4. `install-studio`의 **`modu_right.uf2` 하나만** 그 드라이브 안으로 복사합니다.
5. 복사 완료와 자동 재부팅을 기다립니다.

**완료 표시:** 왼쪽에는 left, 오른쪽에는 right 파일을 각각 복사했습니다.

왼쪽을 먼저 업데이트한 뒤 좌우 연결이 잠시 안 되어 오른쪽 단축키가 안 먹으면, 오른쪽 USB 연결을 유지하고 아래 물리 RESET 방법을 사용합니다.

### 키 조합으로 부트로더에 못 들어갈 때

1. [제작자 RESET 위치 안내와 사진](https://erkeys.com/user-guide/reset-firmware/)을 엽니다.
2. 설치할 **그쪽 기기**를 USB로 연결합니다.
3. 제작자 사진을 보며 측면 커버를 조심스럽게 열고, PCB의 **RESET 버튼을 빠르게 두 번** 누릅니다.
4. `MODU_BOOT`가 나타나면 그쪽에 맞는 UF2 파일 하나를 복사합니다.

RESET은 키맵 레이어에 의존하지 않습니다. 버튼 위치는 제작자 사진을 기준으로 확인합니다. Windows에서 디스크 초기화나 포맷을 요구하면 **취소**합니다. 드라이브가 열리지 않은 상태에서 포맷·복구 프로그램을 실행하지 않습니다.

## 4. 왼쪽 USB로 Studio 연결

1. 양쪽 설치가 끝나면 양쪽 전원을 껐다 켭니다.
2. **왼쪽 기기를 Windows에 USB로 연결**하고 오른쪽도 전원을 켭니다.
3. **엄지 Fn → 왼쪽 Ctrl을 누른 채 T를 한 번** 누른 뒤 모두 뗍니다. 키보드 출력을 USB로 선택하는 동작입니다.
4. Edge/Chrome에서 **[https://zmk.studio/](https://zmk.studio/)** 를 엽니다.
5. 연결 방식에서 **USB**를 선택합니다.
6. 브라우저의 직렬 포트 선택 창에서 MODU에 해당하는 장치를 선택하고 연결합니다. 이름은 `Modu` 또는 USB 직렬 포트처럼 표시될 수 있습니다. 목록이 비어 있으면 아래 문제 해결을 봅니다.
7. 잠금 해제 안내가 나오면 **엄지 Fn → 왼쪽 Ctrl을 누른 채 R을 한 번** 누르고 모두 뗍니다.
8. 키보드 그림과 **4개 레이어**가 표시되는지 확인합니다.

| 레이어 번호 | 현재 이름 | 용도 |
| --- | --- | --- |
| 0 | default_layer | Mac 기본 |
| 1 | lower_layer | Windows 기본 |
| 2 | fn | Fn 기능 |
| 3 | bootloader_layer | 부트로더·Bluetooth·Studio 관리 |

이 펌웨어의 Studio 잠금 해제는 **관리 레이어 3의 R**입니다. 제작자 기본 키맵 안내의 레이어 번호와 다르므로 위 단축키를 그대로 따라갑니다.

잠금 해제에는 엄지 Fn을 쓰면 바로 동작합니다. Caps를 Fn으로 쓰려면 먼저 200ms 이상 누르고 있어야 합니다. 연결 해제 또는 10분간 사용하지 않으면 다시 잠길 수 있으며, 그때 R 조합으로 다시 해제합니다.

## 5. 실제 키 하나 바꿔보고 저장

첫 시험은 **Windows 레이어의 Q를 잠깐 F1로 바꿨다가 되돌리기**입니다. Fn이나 잠금 해제 키를 바꾸지 않고 저장 동작을 확인할 수 있습니다. 웹 화면의 세부 배치는 업데이트로 달라질 수 있습니다.

1. **Studio 화면에서 레이어 1 / lower_layer**를 선택합니다. 화면에서 편집할 레이어를 선택하는 것만으로 실제 키보드의 활성 레이어가 바뀌지는 않습니다.
2. 키보드 그림에서 **Q 위치**를 클릭합니다. 원래 동작은 일반 키 입력 Q입니다.
3. 편집 영역의 **Behavior**는 일반 키 입력인 **Key Press**를 선택하거나 그대로 둡니다.
4. 키 값 선택 영역에서 **F1**을 찾아 선택합니다.
5. 위쪽 **저장 아이콘**을 누릅니다. 마우스를 올리면 **Save**라고 표시됩니다. 변경이 없으면 저장 버튼은 비활성화됩니다.
6. **실제 키보드에서 엄지 Fn을 누른 채 G를 한 번** 누르고 모두 뗍니다. 기존 설정의 Windows 레이어 전환입니다.
7. Windows 메모장을 열고 Q 위치를 눌러봅니다. Q 문자가 입력되지 않고 F1 동작이 나오는지 확인합니다. F1 결과는 앱에 따라 다릅니다.
8. 저장이 끝난 상태에서 양쪽 전원을 껐다 켜고, 왼쪽 USB를 다시 연결합니다. **Fn+G로 Windows 레이어를 다시 선택**한 뒤 Q 위치의 F1 변경이 유지되는지 확인합니다.
9. Studio에 다시 연결하고 필요하면 **Fn+왼쪽 Ctrl+R**로 잠금을 풉니다.
10. 레이어 1의 같은 위치를 **Key Press → Q**로 되돌리고 **Save**를 누릅니다. 메모장에서 Q가 다시 입력되는지 확인합니다.

원하는 키를 바꿀 때도 **편집할 레이어 선택 → 키 위치 선택 → 동작/키 값 선택 → Save → 실제 해당 레이어에서 시험** 순서입니다. 이렇게 저장하는 일반 키 매핑 변경에는 매번 Actions 빌드나 UF2 재설치가 필요 없습니다.

## 6. 앞으로 자주 쓸 조작

아래 표는 **이번 묶음의 기본 설정** 기준입니다. Studio에서 관련 키를 직접 바꾸면 조작도 달라집니다.

| 원하는 동작 | 실제 키보드에서 누를 키 |
| --- | --- |
| Mac 기본 레이어로 전환 | 엄지 Fn을 누른 채 **T**, 이후 모두 떼기 |
| Windows 기본 레이어로 전환 | 엄지 Fn을 누른 채 **G**, 이후 모두 떼기 |
| Fn 기능 사용 | 엄지 Fn을 누르고 있는 동안 |
| Caps Lock / Fn | Caps 짧게 누르기 / 200ms 이상 누르고 있기 |
| Studio 잠금 해제 | 엄지 Fn → 왼쪽 Ctrl을 누른 채 **R** |
| USB 출력 선택 | 엄지 Fn → 왼쪽 Ctrl을 누른 채 **T** |
| 왼쪽 / 오른쪽 부트로더 | 엄지 Fn → 왼쪽 Ctrl을 누른 채 **5 / 6 각각** |
| Command를 누른 상태에서 Command+Space | 왼쪽 Command를 누르고 있다가 오른쪽 엄지 Backspace 누르기 (Mac/Windows 기본 레이어, 시간 제한 없음) |
| Command+Space 콤보 | 스페이스 왼쪽 엄지 Command + 오른쪽 맨 아래 왼쪽 Backspace |

오른쪽 엄지 Backspace를 단독으로 누르면 기존 Backspace입니다. Command를 함께 누를 때의 원래 Command+Backspace 동작은 Command+Space로 대체됩니다.

**Fn+T는 Mac 전환**, **Fn+Ctrl+T는 USB 출력 선택**입니다.

Studio 화면에서 아래 설정은 유지하면 관리 기능에 계속 접근할 수 있습니다.

- 기본 레이어의 엄지 Fn: 레이어 2를 누르는 동안 켜는 동작.
- 레이어 2의 왼쪽 Ctrl: 레이어 3을 누르는 동안 켜는 동작.
- 레이어 3의 R: Studio Unlock. T: USB 출력 선택.
- 레이어 3의 숫자 5/6: 부트로더.

화면에 보이는 작은 자리표시자 6개(위치 51~56)는 실제 키가 아닙니다.

## 7. 안 될 때

| 증상 | 확인할 것 |
| --- | --- |
| MODU_BOOT가 안 나타남 | 해당 기기에 데이터 USB가 연결됐는지 확인. 단축키가 안 먹으면 해당 기기 RESET 빠르게 두 번. |
| 드라이브가 열리지 않거나 포맷 요구 | 취소. 다른 데이터 케이블/직접 USB 포트로 다시 확인. 해결되지 않으면 표시된 오류를 기록하고 제작자 복구 안내 확인. |
| 오른쪽 파일을 넣은 뒤 왼쪽이 먹통 | left/right를 혼동했는지 확인. 왼쪽을 물리 RESET으로 열어 새 left를 복원하고, 오른쪽을 별도로 연결해 새 right 설치. |
| Studio의 USB 장치 목록이 비어 있음 | **왼쪽**에 새 left를 설치했는지, 일반 모드로 부팅됐는지, 데이터 케이블인지 확인. 오른쪽 USB나 부트로더 모드에서는 Studio 편집 불가. |
| 장치는 보이는데 연결 실패 | Studio를 연 다른 탭/프로그램을 닫고 다시 연결. Fn+Ctrl+T로 USB 출력 선택. Windows 장치 관리자에서 USB 직렬 장치 인식/오류 확인. |
| 잠금 해제가 안 됨 | 엄지 Fn을 먼저 누른 뒤 왼쪽 Ctrl을 누르고 R. 관리 레이어 접근 키를 바꿨는지 확인. |
| 바꾼 키가 그대로임 | Save 여부와 **실제 활성 레이어** 확인. Windows는 Fn+G, Mac은 Fn+T. |
| 새 UF2를 넣어도 예전 Studio 키맵이 보임 | 아래 저장 방식 설명 확인. 필요할 때만 Studio 설정을 기록한 후 Restore Stock Settings 사용. |
| 오른쪽 입력이 안 됨 | 양쪽 전원, 각 기기에 맞는 새 파일 설치, 좌우 재연결 확인. 정상 복사만으로 실제 연결 성공이 보장되지는 않음. |

드라이버 오류가 있을 때는 Windows 업데이트와 장치 관리자에 표시된 구체적인 오류를 확인합니다. 임의의 드라이버 교체 도구나 Bluetooth 전체 초기화부터 실행하지 않습니다.

### 이미 Studio에 키맵을 저장했던 경우

새 펌웨어를 설치해도 기기에 저장된 키맵이 우선하므로, Command 홀드 동작이 자동으로 나타나지 않을 수 있습니다. 이때 전체 초기화 대신 다음 두 키만 편집하면 됩니다.

1. Studio에 연결하고 잠금을 풉니다.
2. 레이어 0 / default_layer에서 오른쪽 엄지 Backspace 위치를 선택합니다.
3. **Behavior → Command Backspace**를 선택합니다. 별도 매개변수는 없습니다.
4. 레이어 1 / lower_layer의 같은 위치에도 **Command Backspace**를 선택합니다.
5. **Save** 후 각 기본 레이어에서 단독 Backspace, Command를 먼저 누르고 Backspace, 기존 동시 입력 콤보를 확인합니다.

처음 Studio를 설치하고 이전 저장 키맵이 없다면 이미 지정되어 있습니다.

### 저장 방식: GitHub와 Studio는 별개

- **Studio의 Save는 키보드 안에 저장**합니다. GitHub의 `.keymap` 파일을 자동 수정하지 않습니다.
- Studio로 저장한 키맵이 이후 설치한 펌웨어의 기본 키맵보다 우선할 수 있습니다.
- 새 펌웨어에 들어 있는 기본 키맵으로 돌아가려면, 필요한 Studio 변경을 화면 캡처/메모로 남긴 뒤 장치 메뉴의 **Restore Stock Settings**를 선택합니다. Studio에서 바꾼 키맵을 초기화하는 동작이므로 일상 저장 과정에서는 누르지 않습니다.
- 현재 Studio는 **콤보 정의 편집**을 지원하지 않습니다. 기존 Command+Space 콤보는 펌웨어에 포함돼 있으며, 콤보 수정에는 소스 변경과 빌드가 필요합니다.
- 기존 `.keymap` 또는 소스 ZIP을 Studio에 업로드해 자동 복원하는 기능이 있다고 가정하지 않습니다.

## 8. 문제가 계속되면 이전 버전으로 복귀

1. ZIP 안의 **`backup-7677fa5/firmware`** 폴더를 엽니다.
2. 왼쪽 기기를 USB로 연결하고 부트로더에 진입합니다.
3. **그 백업 폴더의 `modu_left.uf2`**를 왼쪽에 복사합니다.
4. 오른쪽 기기를 USB로 연결하고 부트로더에 진입합니다.
5. **그 백업 폴더의 `modu_right.uf2`**를 오른쪽에 복사합니다.
6. 양쪽 전원을 다시 켜고 왼쪽 USB로 입력을 확인합니다.

이것은 기존 **Actions #32 / 7677fa5**로 돌아가는 방법입니다. 복귀한 버전은 Studio 편집을 지원하지 않습니다. UF2 재설치만으로 Studio 저장 영역이 지워지는 것은 아니므로 나중에 Studio 펌웨어를 다시 설치하면 과거 Studio 변경이 다시 보일 수 있습니다.

## 완료 체크

- [ ] 왼쪽에 새 left, 오른쪽에 새 right를 각각 설치했다.
- [ ] 왼쪽 USB로 Studio에 연결하고 Fn+Ctrl+R로 잠금을 풀었다.
- [ ] 4개 레이어와 기존 키 배치를 확인했다.
- [ ] 시험 키를 변경·저장하고 전원 재시작 후에도 유지됨을 확인했다.
- [ ] 시험 키를 원래 값으로 되돌려 저장했다.
- [ ] Mac/Windows 전환, Caps 탭·홀드, 기존 Command+Space 콤보를 확인했다.
- [ ] 오른쪽 엄지 Backspace 단독 입력과 Command를 1초 이상 먼저 누른 뒤 Backspace를 누르는 동작을 각각 확인했다.
- [ ] 양쪽 키와 트랙볼 이동/버튼, 절전 복귀를 확인했다.

이후 Mac에서 사용하려면 왼쪽 USB 연결 후 Fn+T로 Mac 레이어를 선택합니다. Mac Chrome/Edge에서 Studio 연결도 시도할 수 있습니다. 이전 Mac의 UF2 드라이브 접근 문제와 Studio 직렬 연결은 서로 다른 경로이며, Mac에서의 Studio 연결 성공 여부는 아직 확인하지 않았습니다.

## Studio 전환 없이 이번 키 동작만 추가하려면

기존 일반 펌웨어를 계속 사용할 때는 **[일반 펌웨어 #34 다운로드 — MODU-C-Standard-655179f.zip](https://github.com/cherrytomato1/modu-c-zmk-config/raw/refs/heads/main/windows-studio-guide/MODU-C-Standard-655179f.zip)** 를 사용합니다. 압축 안의 README-WINDOWS.txt를 따라 새 left를 **왼쪽**에 설치하면 이번 키맵 변경이 적용됩니다. 이 파일은 Studio 편집을 지원하지 않습니다. **Studio로 전환할 예정이면 맨 위 Studio ZIP으로 아래 절차를 진행합니다.**

## 파일 출처와 검증

이 디렉터리는 특정 빌드의 설치 묶음입니다. 저장소 main의 키맵을 나중에 편집해도 **이 ZIP 내용은 자동 갱신되지 않습니다.** main의 일반 펌웨어에도 Command 홀드 동작을 반영했으며, Studio 구현은 별도 브랜치에 있습니다. Studio로 전환할 때는 이 페이지의 Studio ZIP을 사용합니다.

- [Studio 소스 8175d9d](https://github.com/cherrytomato1/modu-c-zmk-config/tree/8175d9d32edae4dbbe7ce8d2a2ccc691071d9fd7)
- [새 빌드 Actions #35 — 성공](https://github.com/cherrytomato1/modu-c-zmk-config/actions/runs/35213627868)
- [복귀용 Actions #32 — 성공](https://github.com/cherrytomato1/modu-c-zmk-config/actions/runs/35198359466)
- [ZIP SHA-256](SHA256SUMS.txt) · [빌드 검증 상세](VALIDATION.md)
- [제작자 업데이트 공지](https://www.wadiz.io/web/campaign/detailPost/386073/news/611398)
- [공식 ZMK Studio 설명](https://zmk.dev/docs/features/studio)

Actions artifact는 보관 기간이 지나면 만료됩니다. **위에 첨부한 저장소 ZIP은 Actions 보관 기간과 무관하게 받을 수 있습니다.**

| 새 파일 | SHA-256 |
| --- | --- |
| modu_left.uf2 | `c91759078ccbec5dbc6f58e7405f3cd48f2e6ceb457924fe02c069ac5b007cba` |
| modu_right.uf2 | `2e0ff14833be1f462a80891f8f6b764702b0040879c1096b8cab701d52302b63` |

검증은 빌드·설정·UF2 구조와 해시 기준입니다. 위 완료 체크의 실제 기기 확인은 Windows에서 설치할 때 진행합니다.

이 디렉터리에 남아 있는 MODU-C-Studio-b589c1b.zip은 이전 #33 보관본이며 Command 홀드 동작이 없습니다. 새로 설치할 때는 맨 위 #35 파일을 사용합니다.
